class staticParameter:
    
    #velocidade linear
    linear_velocity = 1.0
    
    #minima velocidade linear
    min_linear_velocity = 0.2
    
    #velocidade maxima linear
    max_linear_velocity = 1.0
    
    #velocidade angular
    angular_velocity = 1.0
    
    #minima velocidade angular
    min_angular_velocity = 0.05
    
    #maxima velocidade angular
    max_angular_velocity = 0.3
    
    #raio limite do cone do sensor
    sensor_cone_radius = 2.0
    
    #distancia maxima de leitura do cone do sensor
    max_sensor_dist = sensor_cone_radius # * 0.85
    
    #distancia minima do cone do sensor
    min_sensor_dist = 0.2
    
    #angulo do cone do sensor
    sensor_cone_angle = 270
    
    #angulo maximo de leitura do sensor
    max_sensor_angle = sensor_cone_angle / 2.0
     
    #angulo minimo de leitura do sensor
    min_sensor_angle = -sensor_cone_angle / 2.0
    
    #maximo de angulos obtidos pelo laser
    max_laser_reads = 270
    
    #angulo desejado ao beacon
    desired_angle_to_beacon = 90.0
    
    #raio de identificacao do beacon
    beacon_radius_id = 0.10 # (0.085 ... 0.115)
    
    #raio de identificacao do Robo
    robot_radius_id = 0.15 # (0.1275 ... 0.1725)
    
    #roleranca para a identificacao enter robo e beacon - percentual decimal
    radius_tolerance = 0.25
    
    #tipos de objetos identificaveis
    id_types = ["unknown", "beacon", "robot", "alien"]
    
    #mensagens de Status
    status_msg = ["Status: wandering", "Status: avoiding collision", "Status: circumnavegating", "Status: circumnavegating and avoiding collision"]

    #raio desejado de circunavegacao
    desired_radius = 1.5 #meters
    
    #distancia desejada entre robots
    desired_distance_to_robot = 0.75
    
    #distancia minima entre robots
    min_distance_to_robot = 0.3