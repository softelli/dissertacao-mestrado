from staticParameters import staticParameter
from Circumnavigation import circum
from polar_coord import LinAng

r = LinAng() #robo mais proximo
b = LinAng() #beacon
a = LinAng() #alien
v = LinAng() #velocidade atual
c = circum()


r.setPolarCoords(0.0, 0.0) #nao ha robo
b.setPolarCoords(0.5, 0.0) #o beacon esta a frente
a.setPolarCoords(0.0, 0.0) #nao ha alien


v.setVelocities(0.3, 4.5)

print "velocidade atual:"
v.prn()

v.linear, v.angular = c.process(v, b, r, a).getVelocities()

print "velocidade atual"
v.prn()

class testando():
  
  def __init__(self):
    self.a = 0
    self.b = 1
    self.c = 2
    