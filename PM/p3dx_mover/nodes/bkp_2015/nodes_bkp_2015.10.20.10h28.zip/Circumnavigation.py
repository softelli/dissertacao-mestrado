from LocalObject import LocalObject
import math
import random

#static parameters
from staticParameters import staticParameter
sp = staticParameter

class circum:

	def __init__(self):

		#forca
		self.force = 1.0

		#Forca dos coeficientes sobre o Robo
		self.coefficienteForce = 1.0

		#Coeficiente de orientacao
		self.orientationCoef = 1.0

		#Coeficiente de Interferencia...
		self.interferenceCoef = 1.0

		#Coeficiente de Proximdiade
		self.proximityCoef = 1.0

		#Coeficiente de aceleracao
		self.accelerationCoef = 1.0

		#Coeficiente de Conversao
		self.conversionCoef = 0.0

		#Coeficiente de Velocidade
		self.velocityCoef = 1.0

		#Distancia desejada
		self.desiredDistanceToRobot = sp.desired_distance_to_robot

		#Distancia Minima entre os Robos
		self.minDistanceBetweenRobots = sp.min_distance_to_robot

		#Raio obtido
		self.obtainedRadiusToBeacon = 0.0

		#Raio desejado
		self.desiredRadius = sp.desired_radius

		#Angulo Obtido em Relacao ao Beacon
		self.obtainedAngleToBeacon = 0.0

		#Angulo Desejado em Relacao ao Beacon
		self.desiredAngleToBeacon = sp.desired_angle_to_beacon

		#Angulo Obtido em Relacao ao Robo
		self.obtainedAngleToRobot = 0.0
		
		#Distancia obtida
		self.obtainedDistanceToRobot = 0.0		

		#Distancia obtida ao alien
		self.obtainedDistanceToAlien = 0.0
		
		#angulo obtido ao alien
		self.obtainedAngleToAlien = 0.0

		#Angulo Mais proximo
		self.closerAngle = 0.0

		#Coeficiente de Relacao entre Raio Desejado e Obtido
		self.relativeDiffInRadius = 0.0
		
		#Coeficiente angular
		self.angularCoef = 0.1

		#Dimensoes do cone do sensor
		self.sensorRadius = sp.sensor_cone_radius
		self.sensorAngle = sp.sensor_cone_angle

		#substituida por linear velocity, angular_velocity
		self.maxLinearVelocity = sp.max_linear_velocity
		self.linearVelocity = sp.min_linear_velocity
		self.angularVelocity = sp.min_angular_velocity

		#Beacon detectado?
		self.hasBeacon = False

		#Robo detectado?
		self.hasRobot = False

		#Alien detectado?
		self.hasAlien = False


	#atualiza a diferenca relativa entre o raio obtido e o desejado
	def updateRelativeDiffInRadius(self):
		self.relativeDiffInRadius = (self.desiredRadius - self.obtainedRadiusToBeacon) / (self.desiredRadius * 1.0)

	#obtem o angulo de espelho em relacao ao beacon
	#def getMirrorAngle(self):
	#	halfSensorAngle = self.sensorAngle / 2.0
	#	return halfSensorAngle - 2.0 * (halfSensorAngle - 90.0)

	#atualiza o coeficiente de velocidade
	def updateVelocityCoef(self):
		self.velocityCoef = self.proximityCoef + 2.0 * self.accelerationCoef * self.interferenceCoef

	#atualiza a existencia de objetos detectados
	def updateDetectedObjects(self, detectedBeaconDist, detectedRobotDist, detectedAlienDist):
	        #print "detected beacon"
	        #detectedBeaconDist.prn()
	        #print "detected robot"
	        #detectedRobotDist.prn()
	        #print "detected alien"
	        #detectedAlienDist.prn()
	        
		if detectedBeaconDist.linear > 0.0:
			self.hasBeacon = True
			self.obtainedRadiusToBeacon = detectedBeaconDist.linear
			self.obtainedAngleToBeacon = detectedBeaconDist.angular
		else:
			self.hasBeacon = False
			self.obtainedRadiusToBeacon = 0.0
			self.obtainedAngleToBeacon = 0.0

		if detectedRobotDist.linear > 0.0:
			self.hasRobot = True
			self.obtainedDistanceToRobot = detectedRobotDist.linear
			self.obtainedAngleToRobot = detectedRobotDist.angular	
		else:
			self.hasRobot = False
			self.obtainedDistanceToRobot = 0.0
			self.obtainedAngleToRobot = 0.0

		if detectedAlienDist.linear > 0.0:
			self.hasAlien = True
			self.obtainedDistanceToAlien = detectedAlienDist.linear
			self.obtainedAngleToAlien = detectedAlienDist.angular
		else:
			self.hasAlien = False
			self.obtainedDistanceToAlien = 0.0
			self.obtainedAngleToAlien = 0.0

	#atualiza o coeficiente de conversao #eliminado o halfSensorAngle e o mirrorAngleToBeacon
	def updateConversionCoef(self):
		#codigo simplificado
		#se nao funcionar, voltar ao codigo do NETLOGO
		#AnguloObtido = 135, retorna -0.5
		#AnguloObtido = 90, retorna 0
		#AnguloObtido = -135, retorna 2.5
		self.conversionCoef = 1.0 - (self.obtainedAngleToBeacon / self.desiredAngleToBeacon)
		
	#atualiza o coeficiente angular (para incremento na velocidade angular)
	def updateAngularCoef(self):
		self.angularCoef = self.coefficienteForce * self.relativeDiffInRadius - (self.conversionCoef / (self.interferenceCoef + 0.1))
	
	#atualiza o coeficiente de orientacao - modificcado pois angulo medio agora eh ZERO
	def updateOrientationCoef(self):
		#diferente de NETLOGO
		self.orientationCoef = 1.0 - (self.absoluteValue(self.obtainedAngleToRobot)/(self.sensorAngle / 2.0))

	#atualiza a Direcao do Robot -- essa abordagem sera utilizada aqui????
	def updateAngularVelocity(self):
		
		self.angularVelocity = self.angularVelocity + self.angularCoef
		if(self.angularVelocity > sp.max_angular_velocity):
			self.angularVelocity = sp.max_angular_velocity
		if(self.angularVelocity < (sp.max_angular_velocity * -1)):
			self.angularVelocity = -sp.max_angular_velocity

	#atualiza o Coeficiente de Interferencia
	def updateInterferenceCoef(self):
		self.interferenceCoef = self.absoluteValue((self.obtainedRadiusToBeacon - self.desiredRadius) / (self.desiredRadius * 1.0))

	#atualiza o Coeficiente de Proximidade
	def updateProximityCoef(self):
		num = self.obtainedDistanceToRobot - self.minDistanceBetweenRobots
		den = self.sensorRadius - self.minDistanceBetweenRobots
		self.proximityCoef = 1 - (num/den)**2

	#atualiza o Coeficiente de Aceleracao - OK 2015.10.19
	def updateAccelerationCoef(self):
		#(o - d)/(r - d + m), retornando
		  #ca --> 1, quando o > d
		  #ca = 0, quando o = d
		  #ca --> -1, quando o --> min
		  #ca < -1, quando o < min
		
		self.accelerationCoef = (self.obtainedDistanceToRobot - self.desiredDistanceToRobot)/(self.sensorRadius - self.desiredDistanceToRobot + self.minDistanceBetweenRobots)

	#retorna sempre positivo
	def absoluteValue(self, value):
		if value >= 0.0:
			return value
		else:
			return value * -1.0
		      
	def printCoef(self):
	        #print "[", num_id, "]:: Ci:", self.interferenceCoef, "Cc:", self.conversionCoef, "Co", self.orientationCoef, "Cp", self.proximityCoef, "Ca", self.accelerationCoef
	        print("Coef. de interferencia (Ci): %6.2f" % (self.interferenceCoef))
	        print("Coef. de conversao     (Cc): %6.2f" % (self.conversionCoef))
	        print("Coef. de orientacao    (Co): %6.2f" % (self.orientationCoef))
	        print("Coef. de proximidade   (Cp): %6.2f" % (self.proximityCoef))
	        print("Coef. de aceleracao    (Ca): %6.2f" % (self.accelerationCoef))
	        print("Coef. de velocidade    (Cv): %6.2f" % (self.velocityCoef))
	        print("Coef. total.(angular)  (Cv): %6.2f" % (self.angularCoef))
	        print("Diferenca entre raios  (Dr): %6.2f" % (self.relativeDiffInRadius))
	        print ""
	        print("Velocidade Linear      (v ): %6.2f" % (self.linearVelocity))
	        print("Velocidade Angular     (u ): %6.2f" % (self.angularVelocity))
	        print ""
	        print("Raio desejado          (Rd): %6.2f" % (self.desiredRadius))
	        print("Raio obtido            (Ro): %6.2f" % (self.obtainedRadiusToBeacon))
	        print ""
	        print("Distancia desejada     (Dd): %6.2f" % (self.desiredDistanceToRobot))
	        print("Distancia obtida       (Do): %6.2f" % (self.obtainedDistanceToRobot))
		
	        
	#devolve as velocidades linear e angular
	def process(self, myVelocities, beaconCoord, robotCoord, alienCoord):
		#print "beacon coord", beaconCoord.getVelocities()
		#print "robot coord", robotCoord.getVelocities()
		#print "alien coord", alienCoord.getVelocities()
		
		#atualiza a existencia dos objetos
		self.updateDetectedObjects(beaconCoord, robotCoord, alienCoord)
		
		#SE detectou o alvo
		if self.hasBeacon:

			#atualizar o Coeficiente de Interferencia
			self.updateInterferenceCoef()

			#atualizar o Coeficiente de Conversao			
			self.updateConversionCoef()
			

		#SE nao detectou o alvo
		else:
			#estado = busca
			#altere o rotulo
			#se estava circunavegando, exiba um erro por ter perdido a circunavegacao
			
			#retorna a velocidade minima adicionada de uma variacao de 0..0.25
			self.angularVelocity = sp.min_angular_velocity + random.random() * 0.25

			#coeficiente de interferencia para 1
			self.interferenceCoef = 1.0

			#coenficiente de conversao para 0
			self.conversionCoef = 0.0

		    #fim se

		#se existir robo no cone
		if self.hasRobot:

			#atualizar coeficiente de orientacao
			self.updateOrientationCoef()

			#atualizar coeficiente de proximidade
			self.updateProximityCoef()

			#atualizar coeficiente de aceleracao
			self.updateAccelerationCoef() 
		#else:
		#	if self.linearVelocity < self.maxLinearVelocity / 2:
		#	   self.linearVelocity += 0.1
		
		#atualiza o coeficiente de velocidade linear
		self.updateVelocityCoef()
		
		#atualiza o coeficiente de velocidade angular
		self.updateAngularCoef()
		
		#atualiza a velocidade angular
		self.updateAngularVelocity()
		
		myVelocities.angular = self.angularVelocity		
		myVelocities.linear = self.linearVelocity
		
		self.printCoef()
		
		return myVelocities


