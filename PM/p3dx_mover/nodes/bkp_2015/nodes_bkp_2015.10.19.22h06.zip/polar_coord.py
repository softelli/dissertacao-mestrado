class LinAng:
  def __init__(this):
    this.linear = 0.0
    this.angular = 0.0
    
  def setVelocities(this, linear, angular):
    this.linear = linear
    this.angular = angular
    
  #apenas por semantica
  def setPolarCoords(this, linear, angular):
    this.setVelocities(linear, angular)
    
  def prn(this):
    print "Linear:", this.linear, "Angular:", this.angular
    
  def getPolarCoords(this):
    return this.linear, this.angular
  
  #apenas por semantica
  def getVelocities(this):
    return this.linear, this.angular
   