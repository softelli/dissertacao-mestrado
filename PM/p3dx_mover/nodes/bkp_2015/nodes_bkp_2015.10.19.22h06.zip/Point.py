#!/usr/bin/env python
# --------------------------------------------------#
# AUTOR: softelli@gmail.com
# class Point
# - define os atributos e metodos adicionais para cada ponto
# - define 3 pontos para identificacao do circulo
# - calcula o circulo por CRAMER e SARRUS 
# #----------------------------------------------------#

import math

class Point:
	def __init__(this):
		#inicializa as variaveis 
		this.exists = False
		this.x = 0.0
		this.y = 0.0
		this.radius = 0.0
		this.angle = 0.0
	  
	def setCoordPol(this, radius, angle):
		#recebe coordenadas polares e calcula as retangulares
		this.radius = radius
		this.angle = angle
		this.x = math.cos(math.radians(angle)) * radius
		this.y = math.sin(math.radians(angle)) * radius
		this.exists = True
	
	def setCoordRet(this, x, y):
		#recebe as coordenadas retangulares e calcula as polares
		this.x = x
		this.y = y
		#prevent float by zero division
		if(this.x == 0):
			this.x = 0.0000000001
		this.angle = math.degrees(math.atan2(this.y,this.x))
		this.radius = math.sqrt(math.pow(this.x, 2) + math.pow(this.y, 2))
		this.exists = True
		
	def getCoordPol(this):
	  return (this.radius, this.angle)
	
	def prt(this, num):
		#imprime os valores - apenas para debug
		#print "[P %d] (%5.3f,%5.3f) || %5.3f < %5.3f", num, this.x, this.y, this.radius, this.angle 
		print "[P", num, "]: ", this.exists, " (", this.x, ",", this.y,") | ", this.radius, " < ", this.angle