from LocalObject import LocalObject
import math
import random

#static parameters
from staticParameters import staticParameter
sp = staticParameter

class circum:

	def __init__(this):

		#forca
		this.force = 1.0

		#Forca dos coeficientes sobre o Robo
		this.coefficienteForce = 3.0

		#Coeficiente de orientacao
		this.orientationCoef = 1.0

		#Coeficiente de Interferencia...
		this.interferenceCoef = 1.0

		#Coeficiente de Proximdiade
		this.proximityCoef = 1.0

		#Coeficiente de aceleracao
		this.accelerationCoef = 1.0

		#Coeficiente de Conversao
		this.conversionCoef = 0.0

		#Coeficiente de Velocidade
		this.velocityCoef = 1.0

		#Robo mais proximo  -  ainda nao utilizado
		this.NestedRobot = ""

		#Distancia desejada
		this.desiredDistanceToRobot = 0.0

		#Distancia Minima entre os Robos
		this.minDistanceBetweenRobots = 0.0

		#Menor Distancia
		this.shortestDistance = 0.0

		#Raio obtido
		this.obtainedRadiusToBeacon = 0.0

		#Raio desejado
		this.desiredRadius = sp.desired_radius

		#Angulo Obtido em Relacao ao Beacon
		this.obtainedAngleToBeacon = 0.0

		#Angulo Desejado em Relacao ao Beacon
		this.desiredAngleToBeacon = sp.desired_angle_to_beacon

		#Angulo Obtido em Relacao ao Robo
		this.obtainedAngleToRobot = 0.0
		
		#Distancia obtida
		this.obtainedDistanceToRobot = 0.0		

		#Distancia obtida ao alien
		this.obtainedDistanceToAlien = 0.0
		
		#angulo obtido ao alien
		this.obtainedAngleToAlien = 0.0

		#Angulo de Espelho em Relacao ao Beacon
		this.mirrorAngleToBeacon = 0.0  #verificar necessidade, pois o angulo central eh ZERO

		#Angulo Mais proximo
		this.closerAngle = 0.0

		#Coeficiente de Relacao entre Raio Desejado e Obtido
		this.relativeDiffInRadius = 0.0

		#Dimensoes do cone do sensor
		this.sensorRadius = sp.sensor_cone_radius
		this.sensorAngle = sp.sensor_cone_angle

		#Direcao - herdada do NetLogo - nao eh possivel fazer essa abordagem aqui???
		this.direction = 0.0

		#Heading - herdada do NetLogo - nao eh possivel fazer essa abordagem aqui??
		#this.heading = 0.0
		#substituida por linear velocity, angular_velocity
		this.maxLinearVelocity = sp.max_linear_velocity
		this.linearVelocity = sp.min_linear_velocity
		this.angularVelocity = sp.min_angular_velocity

		#Beacon detectado
		this.hasBeacon = False

		#Robo detectado
		this.hasRobot = False

		#Alien detectado
		this.hasAlien = False


	#atualiza a diferenca relativa entre o raio obtido e o desejado
	#def updateRelativeDiffInRadius(this):
	#	if this.desiredRadius == 0:
	#		#prevencao de divisao por 0
	#		this.relativeDiffInRadius = 0.0
	#	else:
	#		this.relativeDiffInRadius = (this.desiredRadius - this.obtainedRadius) / (this.desiredRadius * 1.0)

	#obtem o angulo de espelho em relacao ao beacon
	#def getMirrorAngle(this):
	#	halfSensorAngle = this.sensorAngle / 2.0
	#	return halfSensorAngle - 2.0 * (halfSensorAngle - 90.0)

	#atualiza o coeficiente de velocidade
	def updateVelocityCoef(this):
		this.velocityCoef = this.proximityCoef + 2.0 * this.accelerationCoef * this.interferenceCoef

	#atualiza a existencia de objetos detectados
	def updateDetectedObjects(this, detectedBeaconDist, detectedRobotDist, detectedAlienDist):
		if detectedBeaconDist.linear > 0.0:
			this.hasBeacon = True
			this.obtainedRadiusToBeacon = detectedBeaconDist.linear
			this.obtainedAngleToBeacon = detectedBeaconDist.angular
		else:
			this.hasBeacon = False
			this.obtainedRadiusToBeacon = 0.0
			this.obtainedAngleToBeacon = 0.0

		if detectedRobotDist.linear > 0.0:
			this.hasRobot = True
			this.obtainedDistanceToRobot = detectedRobotDist.linear
			this.obtainedAngleToRobot = detectedRobotDist.angular	
		else:
			this.hasRobot = False
			this.obtainedDistanceToRobot = 0.0
			this.obtainedAngleToRobot = 0.0

		if detectedAlienDist.linear > 0.0:
			this.hasAlien = True
			this.obtainedDistanceToAlien = detectedAlienDist.linear
			this.obtainedAngleToAlien = detectedAlienDist.angular
		else:
			this.hasAlien = False
			this.obtainedDistanceToAlien = 0.0
			this.obtainedAngleToAlien = 0.0

	#atualiza o coeficiente de conversao #eliminado o halfSensorAngle e o mirrorAngleToBeacon
	def updateConversionCoef(this):
		#codigo simplificado
		#se nao funcionar, voltar ao codigo do NETLOGO
		#AnguloObtido = 135, retorna -0.5
		#AnguloObtido = 90, retorna 0
		#AnguloObtido = -135, retorna 2.5
		this.conversionCoef = 1 - (this.obtainedAngleToBeacon / 90.0)


	#atualiza o coeficiente de orientacao - modificcado pois angulo medio agora eh ZERO
	def updateOrientationCoef(this):
		#diferente de NETLOGO
		this.orientationCoef = 1 - (this.absoluteValue(this.obtainedAngleToRobot)/(this.sensorAngle / 2.0))

	#atualiza a Direcao do Robot -- essa abordagem sera utilizada aqui????
	def updateAngularVelocity(this):
		coeffs = this.coefficienteForce * this.relativeDiffInRadius - (this.conversionCoef / (this.interferenceCoef + 0.1))
		print "coeffs:", coeffs
		this.angularVelocity = this.angularVelocity + coeffs
		if(this.angularVelocity > sp.max_angular_velocity):
			this.angularVelocity = sp.max_angular_velocity
		if(this.angularVelocity < (sp.max_angular_velocity * -1)):
			this.angularVelocity = -sp.max_angular_velocity

	#atualiza o Coeficiente de Interferencia
	def updateInterferenceCoef(this):
		this.interferenceCoef = this.absoluteValue((this.obtainedRadiusToBeacon - this.desiredRadius) / this.desiredRadius)

	#atualiza o Coeficiente de Proximidade
	def updateProximityCoef(this):
		num = this.obtainedDistanceToRobot - this.minDistanceBetweenRobots
		den = this.sensorRadius - this.minDistanceBetweenRobots
		this.proximityCoef = 1 - (num/den)**2

	#atualiza o Coeficiente de Aceleracao - OK 2015.10.19
	def updateAccelerationCoef(this):
		#(o - d)/(r - d + m), retornando
		  #ca --> 1, quando o > d
		  #ca = 0, quando o = d
		  #ca --> -1, quando o --> min
		  #ca < -1, quando o < min
		
		this.accelerationCoef = (this.obtainedDistanceToRobot - this.desiredDistanceToRobot)/(this.sensor_cone_radius - this.desiredDistanceToRobot + this.minDistanceBetweenRobots)

	#retorna o valor absoluto, ou seja sempre positivo
	def absoluteValue(this, value):
		if value >= 0.0:
			return value
		else:
			return value * -1.0
		      
	def printCoef(this, num_id):
	        #print "[", num_id, "]:: Ci:", this.interferenceCoef, "Cc:", this.conversionCoef, "Co", this.orientationCoef, "Cp", this.proximityCoef, "Ca", this.accelerationCoef
	        print("[%2d]::  Ci: %6.2f   Cc: %6.2f   Co: %6.2f   Cp: %6.2f   Ca: %6.2f   Cv: %6.2f"\
		     % (num_id, this.interferenceCoef, this.conversionCoef, this.orientationCoef, this.proximityCoef, this.accelerationCoef, this.velocityCoef ))
	  

	#devolve as velocidades linear e angular
	def process(this, myVelocities, beaconCoord, robotCoord, alienCoord):

		
		#atualiza a existencia dos objetos
		this.updateDetectedObjects(beaconCoord, robotCoord, alienCoord)
		
		#SE detectou o alvo
		if this.hasBeacon:

			#atualizar o Coeficiente de Interferencia
			this.updateInterferenceCoef()

			#atualizar o Coeficiente de Conversao			
			this.updateConversionCoef()			 

		#SE nao detectou o alvo
		else:
			#estado = busca
			#altere o rotulo
			#se estava circunavegando, exiba um erro por ter perdido a circunavegacao
			
			#retorna a velocidade minima adicionada de uma variacao de 0..0.25
			this.angularVelocity = sp.min_angular_velocity + random.random() * 0.25

			#coeficiente de interferencia para 1
			this.interferenceCoef = 1.0

			#coenficiente de conversao para 0
			this.conversionCoef = 0.0

		    #fim se

		#se existir robo no cone
		if this.hasRobot:

			#atualizar coeficiente de orientacao
			this.updateOrientationCoef()

			#atualizar coeficiente de proximidade
			this.updateProximityCoef()

			#atualizar coeficiente de aceleracao
			this.updateAccelerationCoef()
		#else:
		#	if this.linearVelocity < this.maxLinearVelocity / 2:
		#	   this.linearVelocity += 0.1
		
		#atualiza o coeficiente de velocidade
		this.updateVelocityCoef()
		
		#atualiza a velocidade angular
		this.updateAngularVelocity()
		
		myVelocities.angular = this.angularVelocity		
		myVelocities.linear = this.linearVelocity
		
		this.printCoef(1)
		
		return myVelocities


