class LinAng:
  def __init__(self):
    self.linear = 0.0
    self.angular = 0.0
    
  def setVelocities(self, linear, angular):
    self.linear = linear
    self.angular = angular
    
  #apenas por semantica
  def setPolarCoords(self, linear, angular):
    self.setVelocities(linear, angular)
    
  def prn(self):
    print "Linear:", self.linear, "Angular:", self.angular
    
  def getPolarCoords(self):
    return self.linear, self.angular
  
  #apenas por semantica
  def getVelocities(self):
    return self.linear, self.angular
   